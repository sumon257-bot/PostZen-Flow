# PostZen Flow

A motivational content-driven splash screen app, built with Expo.

## Build APK

Use EAS Build to generate APK:
```sh
eas build --platform android --profile production
```